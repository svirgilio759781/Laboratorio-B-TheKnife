/**
 * Stefano Virgilio 759781 VA
 * Gestisce l'accesso ai dati della tabella 'ristoranti' nel database.
 */
package it.uninsubria.theknife.server.dao;

import it.uninsubria.theknife.common.models.Ristorante;
import it.uninsubria.theknife.server.DBManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RistoranteDAO {

    public List<Ristorante> getTuttiRistoranti() {
        List<Ristorante> lista = new ArrayList<>();
        String sql = "SELECT * FROM ristorante"; // Assicurati che la tabella esista

        try (Connection conn = DBManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Ristorante r = new Ristorante(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("indirizzo"),
                        rs.getString("locazione"),
                        rs.getString("prezzo"),
                        rs.getString("tipologiaCucina"),
                        rs.getDouble("latitudine"),
                        rs.getDouble("longitudine"),
                        rs.getString("telefono")
                        );
                r.setUrl(rs.getString("url"));
                r.setWebsiteUrl(rs.getString("websiteurl"));
                r.setPremi(rs.getString("premi"));
                r.setGreenStar(rs.getInt("greenstar"));
                r.setServizi(rs.getString("servizi"));
                r.setDescrizione(rs.getString("descrizione"));
                r.setConsegna(rs.getBoolean("consegnadomicilio"));
                r.setPrenotazione(rs.getBoolean("prenotazioneonline"));
                r.setidGestore(rs.getInt("idgestore"));

                lista.add(r);
            }
        } catch (SQLException e) {
            System.err.println("Errore SQL in RistoranteDAO: " + e.getMessage());
        }
        return lista;
    }
}