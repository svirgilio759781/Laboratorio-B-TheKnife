package it.uninsubria.theknife.server.dao;

public class PreferitiDAO {
}
