/**
 * Stefano Virgilio 759781 VA
 * Gestisce la connessione al database PostgreSQL utilizzando il pattern Singleton.
 */
package it.uninsubria.theknife.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
    private static DBManager instance;
    private Connection connection;

    // Parametri di connessione
    private static final String url = "jdbc:postgresql://localhost:5432/TheKnifeVirgilio";
    private static final String user = "postgres";
    private static final String password = "Gino2015!";

    private DBManager() throws SQLException {
        try {
            // Carica il driver JDBC
            Class.forName("org.postgresql.Driver");
            this.connection = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver PostgreSQL non trovato!", e);
        }
    }

    // Restituisce l'unica istanza attiva del DBManager.
    public static synchronized DBManager getInstance() throws SQLException {
        if (instance == null || instance.getConnection().isClosed()) {
            instance = new DBManager();
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }
}