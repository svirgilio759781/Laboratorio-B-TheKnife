/**
 * Stefano Virgilio 759781 VA
 * Classe principale del Client.
 * Gestisce l'avvio della connessione RMI e il lancio dell'interfaccia JavaFX.
 */
package it.uninsubria.theknife.client;

import it.uninsubria.theknife.client.views.RistorantiView;
import it.uninsubria.theknife.client.views.LoginView;

import it.uninsubria.theknife.common.interfaces.ITheKnifeService;
import javafx.application.Application;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClientTK {

    // Riferimento statico al servizio per essere usato da tutte le View
    private static ITheKnifeService service;

    public static void main(String[] args) {
        try {
            System.out.println("--- Inizializzazione Client The Knife ---");

            // Tentativo di connessione al registro RMI del Server
            System.out.print("Ricerca del server RMI... ");
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);

            // Lookup del servizio
            service = (ITheKnifeService) registry.lookup("TheKnifeService");
            System.out.println("✅ Connesso!");

            // Lancio dell'interfaccia grafica JavaFX
            // Nota: Chiamiamo la classe della View che estende Application
            System.out.println("Avvio interfaccia grafica...");
            Application.launch(RistorantiView.class, args);

        } catch (Exception e) {
            System.err.println("❌ ERRORE CRITICO: Impossibile avviare il client.");
            System.err.println("Assicurati che il Server sia acceso prima del Client.");
            e.printStackTrace();
        }
    }

    // Metodo statico per permettere a tutte le View di ottenere il servizio.
    public static ITheKnifeService getService() {
        return service;
    }
}