/**
 * Stefano Virgilio 759781 VA
 * Implementazione reale dei metodi definiti nell'interfaccia ITheKnifeService.
 */
package it.uninsubria.theknife.server.service;

import it.uninsubria.theknife.common.interfaces.ITheKnifeService;
import it.uninsubria.theknife.common.models.*;
import it.uninsubria.theknife.server.dao.RistoranteDAO;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class TheKnifeServiceImpl extends UnicastRemoteObject implements ITheKnifeService {

    public TheKnifeServiceImpl() throws RemoteException {
        super();
    }

    private final RistoranteDAO ristoranteDAO = new RistoranteDAO();

    @Override
    public Utente login(String username, String password) throws RemoteException {
        // TODO: Aggiungere logica SQL tramite DBManager
        System.out.println("Richiesta di login per: " + username);
        return null;
    }

    @Override
    public boolean registraUtente(Utente utente) throws RemoteException {
        // TODO: Aggiungere INSERT SQL
        return false;
    }

    @Override
    public List<Ristorante> cercaRistoranti(String citta) throws RemoteException {
        // TODO: Aggiungere SELECT SQL
        return new ArrayList<>();
    }

    @Override
    public boolean prenotaTavolo(Prenotazione p) throws RemoteException {
        // TODO: Aggiungere INSERT SQL
        return false;
    }

    @Override
    public List<Ristorante> elencoRistoranti() throws RemoteException {
        System.out.println("Richiesta elenco ristoranti dal client...");
        return ristoranteDAO.getTuttiRistoranti();
    }
}