/**
 * Stefano Virgilio 759781 VA
 * Visualizza i ristoranti in una ListView JavaFX.
 */
package it.uninsubria.theknife.client.views;

import it.uninsubria.theknife.client.ClientTK;
import it.uninsubria.theknife.common.models.Ristorante;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.List;

public class RistorantiView extends Application {

    @Override
    public void start(Stage primaryStage) {
        ListView<String> listView = new ListView<>();
        Label statusLabel = new Label("Caricamento ristoranti...");

        try {
            // Chiamiamo il server tramite il ClientManager
            List<Ristorante> ristoranti = ClientTK.getService().elencoRistoranti();

            if (ristoranti.isEmpty()) {
                statusLabel.setText("Nessun ristorante trovato nel database.");
            } else {
                for (Ristorante r : ristoranti) {
                    listView.getItems().add(r.toString());
                }
                statusLabel.setText("Ristoranti trovati: " + ristoranti.size());
            }
        } catch (Exception e) {
            statusLabel.setText("Errore di connessione al server.");
            e.printStackTrace();
        }

        VBox root = new VBox(10, statusLabel, listView);
        primaryStage.setScene(new Scene(root, 400, 300));
        primaryStage.setTitle("The Knife - Lista Ristoranti");
        primaryStage.show();
    }
}