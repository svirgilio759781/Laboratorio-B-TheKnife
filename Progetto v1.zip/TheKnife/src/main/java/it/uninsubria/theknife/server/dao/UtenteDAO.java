package it.uninsubria.theknife.server.dao;

public class UtenteDAO {
}
