/**
 * Stefano Virgilio 759781 VA
 * Interfaccia grafica per l'autenticazione dell'utente.
 */
package it.uninsubria.theknife.client.views;

import it.uninsubria.theknife.client.RemoteServiceConnector;
import it.uninsubria.theknife.common.models.Utente;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginView extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("The Knife - Login");

        // Elementi grafici
        Label titleLabel = new Label("Benvenuto in The Knife");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        TextField userField = new TextField();
        userField.setPromptText("Username");
        userField.setMaxWidth(200);

        PasswordField passField = new PasswordField();
        passField.setPromptText("Password");
        passField.setMaxWidth(200);

        Button loginBtn = new Button("Accedi");
        loginBtn.setMinWidth(100);

        // Azione del bottone
        loginBtn.setOnAction(e -> {
            String username = userField.getText();
            String password = passField.getText();

            try {
                // Chiamata remota al Server
                Utente utente = RemoteServiceConnector.getService().login(username, password);

                if (utente != null) {
                    System.out.println("Login riuscito per: " + utente.getUsername());
                    // Qui caricheresti la Home del programma
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Credenziali non valide!");
                    alert.showAndWait();
                }
            } catch (Exception ex) {
                System.err.println("Errore durante il login: " + ex.getMessage());
            }
        });

        // Layout
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(titleLabel, userField, passField, loginBtn);

        Scene scene = new Scene(layout, 350, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}