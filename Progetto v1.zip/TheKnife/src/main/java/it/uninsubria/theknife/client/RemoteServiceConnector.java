/**
 * Stefano Virgilio 759781 VA
 * Fornisce un punto di accesso centralizzato al servizio remoto RMI.
 */
package it.uninsubria.theknife.client;

import it.uninsubria.theknife.common.interfaces.ITheKnifeService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RemoteServiceConnector {

    private static ITheKnifeService service;

    // Restituisce l'interfaccia remota per comunicare con il Server.
    // Se non è ancora collegato, effettua la ricerca nel registro RMI.
    public static ITheKnifeService getService() {
        if (service == null) {
            try {
                // Si connette al registro sulla porta 1099
                Registry registry = LocateRegistry.getRegistry("localhost", 1099);
                // Cerca il servizio col nome registrato dal Server
                service = (ITheKnifeService) registry.lookup("TheKnifeService");
                System.out.println("✅ Collegamento RMI stabilito con successo.");
            } catch (Exception e) {
                System.err.println("❌ Errore: Impossibile connettersi al Server RMI.");
                e.printStackTrace();
            }
        }
        return service;
    }
}