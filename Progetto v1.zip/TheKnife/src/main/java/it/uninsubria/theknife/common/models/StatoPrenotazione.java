package it.uninsubria.theknife.common.models;

import java.io.Serializable;

// Definisce i sati di una prenatazioni ammessi nel sistema.
public enum StatoPrenotazione implements Serializable {
        In_attessa,
        Conferma,
        Cancellata


}
