/**
 * Stefano Virgilio 759781 VA
 * Interfaccia remota che definisce i metodi esportati dal Server.
 * Questa interfaccia deve essere nota sia al Client che al Server.
 */
package it.uninsubria.theknife.common.interfaces;

import it.uninsubria.theknife.common.models.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface ITheKnifeService extends Remote {
    // Esempi di metodi base
    Utente login(String username, String password) throws RemoteException;
    boolean registraUtente(Utente utente) throws RemoteException;
    List<Ristorante> cercaRistoranti(String citta) throws RemoteException;
    boolean prenotaTavolo(Prenotazione p) throws RemoteException;
    List<Ristorante> elencoRistoranti() throws java.rmi.RemoteException;
}