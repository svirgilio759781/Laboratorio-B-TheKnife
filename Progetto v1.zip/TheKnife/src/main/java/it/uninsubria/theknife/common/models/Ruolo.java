package it.uninsubria.theknife.common.models;

import java.io.Serializable;

// Definisce i tipi di utente ammessi nel sistema.
public enum Ruolo implements Serializable {
    Admin,
    Cliente,
    Gestore
}